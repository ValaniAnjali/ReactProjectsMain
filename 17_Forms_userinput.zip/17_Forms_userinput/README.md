Working with Forms & User Input

What's difficult About Forms?
Handling Form submission & Validating User Input
Using Built-in Form Features
Building Custom Solutions